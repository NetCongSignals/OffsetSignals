"""
For a given set of support-files, this code returns the IDs of all instances
which have already been considered (i.e., the source/target pair (s,t) 
appears more than once.
Input: Range of support-files (-> ./loop_results/stat_data/) 
Output: List of IDs
Run 'python3 find_duplicates.py [x,y]', where [x,y] defines a range of support-file IDs
(x is lowest ID, y is highest ID to consider).   
"""

import os
import sys
import numpy as np
import pandas as pd
import math as m
from datetime import datetime
import ast
import copy as cp
from lp_solver import *

now = datetime.now()
dt_string = now.strftime("%b/%d/%Y %H:%M:%S")
print("PROGRAM STARTED: {0}".format(dt_string))
print()

itr_range = ast.literal_eval(sys.argv[-1])
itr_list = [i for i in range(itr_range[0],itr_range[1] + 1)]

# Number of considered data sets
data_nr: int = len(itr_list)
samples: int = 50

seen_routes = []
uniques = []
doubles = []

skip_counter = 0

print("Considering the data sets...")
for itr in itr_list:

	# Read in data from supports-data file
	try:
		file = open('./loop_results/stat_data/supports_{0}.txt'.format(itr))
	except FileNotFoundError:
		print("Skipping File ",itr)
		skip_counter += 1
		continue
	
	content = file.readlines()
	# Number of lines skipped in file
	offset: int = 2 

	route: tuple = ast.literal_eval(content[13 + offset])
	dem: int = ast.literal_eval(content[14 + offset])

	initNode = route[0]
	termNode = route[1]
	
	rev_route: tuple = [termNode,initNode]
	
	dupl: bool = False
	
	for i in seen_routes:
		if (i == route) or (i == rev_route):
			dupl = True
			doubles.append(itr)
			break
			
	if dupl:
		continue
	else:
		if (len(uniques) >= samples):
			doubles.append(itr)
			continue
		else:
			uniques.append(itr)
			seen_routes.append(route)
			seen_routes.append(rev_route)

if (skip_counter == samples):
	if dem == 360600.:
		network: str = "SF" 
	elif dem == 65576.:
		network: str = "EM" 
	elif dem == 11205.:
		network: str = "BF"    
	elif dem == 16660.:
		network: str = "BP" 
	elif dem == 10755.:
		network: str = "BT" 
	elif dem == 11482.:
		network: str = "BC" 
			
	print(network + ": ",doubles)
else:
	print("No support file was evaluated.")