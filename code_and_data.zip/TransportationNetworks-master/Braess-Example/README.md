# Braess Network

## Source
Prepared by Andrew Koh, via  
http://www.bgu.ac.il/~bargera/tntp/

## Scenario
This simple example is for the famous Braess paradox network.

## Contents

 - `Braess_net.tntp` Network  
 - `Braess_trips.tntp` Demand  

## Dimensions
Zones: 2
Nodes: 4
Links: 5
Trips: 6

## Units
Time: 
Distance: 
Cost: 

## Generalized Cost Weights
Toll: 
Distance: 

## Solutions


## Known Issues
FIXME translate to Github Issues
