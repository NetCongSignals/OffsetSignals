"""
This code computes the quantities in Tables 2 and 3.
Input: Range of support-files (-> ./loop_results/stat_data/) 
Output: Files containg the evaluation of the data (-> ./loop_results/stat_data/) 
Run 'python3 compute_stats.py [x,y]', where [x,y] defines a range of support-file IDs
(x is lowest ID, y is highest ID to consider).
WE := Wardrop equilibrium
"""

import os
import sys
import numpy as np
import pandas as pd
import math as m
from datetime import datetime
import ast
import copy as cp
from lp_solver import *

# Set if print result to file
printtofile = True

# Set prior distribution
q_1: float = 0.5 
q_list = [q_1, 1. - q_1]

now = datetime.now()
dt_string = now.strftime("%b/%d/%Y %H:%M:%S")
print("PROGRAM STARTED: {0}".format(dt_string))
print()

# Computes value of line through points (x1,x2), (y1,y2) at x
def compute_yline(x2: float, y2: float, x1: float, y1: float, x: float):

	slope: float = (y2 - y1) / (x2 - x1)

	return slope * (x - x1) + y1


# Checks if total expected costs C(\theta_{\mu_1}) are concave over [0,1]
def check_concave(ue_vals: list, alpha_vals: list):
	i: int = 0
	slope_list: list = []

	# Ignore last entry of list since it is a duplicate
	val_list_len: int = len(ue_vals)-1

	# Compute slopes of all piecewise linear segments
	while (i+1 < val_list_len):
		slope: float = (ue_vals[i+1]-ue_vals[i])/(alpha_vals[i+1][1]-alpha_vals[i][1])
		slope_list.append(slope)
		i += 1

	# For C to be concave, the slopes must not increase as \theta_{\mu_1} increases
	copy_list: list = cp.deepcopy(slope_list)
	# Sort in descending order
	copy_list.sort(reverse=True)

	if (slope_list == copy_list):
		return True
	else:
		return False


# Checks if total expected costs C(\theta_{\mu_1}) are convex over [0,1]
def check_convex(ue_vals: list, alpha_vals: list):
	i: int = 0
	slope_list: list = []

	# Ignore last entry of list since it is a duplicate
	val_len: int = len(ue_vals)-1

	# Compute slopes of all piecewise linear segements
	while (i+1 < val_len):
		slope: float = (ue_vals[i+1] - ue_vals[i])/(alpha_vals[i+1][1] - alpha_vals[i][1])
		slope_list.append(slope)
		i += 1

	# For C to be convex, the slopes must not decrease as \theta_{\mu_1} increases
	copy_list: list = cp.deepcopy(slope_list)
	# Sort in ascending order
	copy_list.sort()

	if (slope_list == copy_list):
		return True
	else:
		return False


# Checks if full information revelation is optimal for the current instance
def check_honestopt(ue_vals: list, alpha_vals: list, isconcave: bool):
	honestisopt: bool = True

	if (not isconcave):
		# Check if any value of C at the breakpoints lies below the line between
		# defined by points (0,C(0)) and (1,C(1))
		x2: float = alpha_vals[-2][1] ; y2: float = ue_vals[-2]
		x1: float = alpha_vals[0][1] ; y1: float = ue_vals[0]

		for i in range(1, len(ue_vals)-2):
			if (compute_yline(x2, y2, x1, y1, alpha_vals[i][1]) >= ue_vals[i]):
				honestisopt = False

	return honestisopt


# Computes the cost of no-signaling at the prior
def compute_cost_nosignal(prior: list, ue_vals: list, alpha_intervals: list):
	# Identify the subinterval in which prior is located
	k: int = 1
	for interval in alpha_intervals[1:]:
		if ((interval[0] <= prior[0]) and (prior[0] <= interval[1])):
			x1: float = interval[0]; y1: float = ue_vals[k-1]
			x2: float = interval[1]; y2: float = ue_vals[k]
			break
		else:
			k += 1

	return compute_yline(x2, y2, x1, y1, prior[0])


# Computes the cost of full information revelation at the prior
def compute_cost_honest(prior: list, ue_vals: list):
	return prior[0] * ue_vals[0] + prior[1] * ue_vals[-1]


# Computes cost of the pointwise Social Optimum at the prior
def compute_cost_avgSO(prior: list, SO_list: list):
	return prior[0] * SO_list[0] + prior[1] * SO_list[1]


# Computes the cost of the optimal signaling scheme at the prior
# We heavily rely on the fact that for two states of nature, the optimal signaling
# scheme is defined by the two points \mu^a, \mu_^b (where \mu^a < \mu_{\theta_1} < \mu_^b)
# that constitute a convex decomposition of the prior. The line going through this points
# form the convex closure of C around the prior (see also Corollary 2 in [41]) 
def compute_cost_opt(prior: list, ue_vals: list, honestisopt: bool, alpha_intervals: list):
	# If C is concave or full revelation is optimal, then full information 
	# revelation is optimal
	if (honestisopt):
		return compute_cost_honest(prior, ue_vals)
	# If C is convex, then no-signaling is optimal
	elif (check_convex(ue_vals, alpha_intervals)):
		return compute_cost_nosignal(prior, ue_vals, alpha_intervals)
	else:
		# Create list of the upper bounds of all support subintervals (unique):
		interval_list: list = []
		for interval in alpha_intervals:
			interval_list.append(interval[1]) 

		# Drop last element ('1' appears twice)
		interval_list.pop()

		# Create list of the values of C at the breakpoints (unique):
		ue_list: list = []
		for ue in ue_vals:
			ue_list.append(ue) 

		# Drop last element ('1' appears twice)
		ue_list.pop()

		# Identify subinterval in which the prior distribution is located
		for i in (range(len(interval_list)-1)):
			if ((prior[0] >= interval_list[i]) and (prior[0] <= interval_list[i+1])):
				curr_interval_index: int = i
				left_bound_index: int = i 
				right_bound_index: int = i + 1 
				break
		
		# Find breakpoints with lowest cost on the left and the right side of prior
		left_indices: list = range(right_bound_index)
		right_indices: list = range(right_bound_index,len(interval_list))

		pair_list: list = []
		value_list: list = []

		for j in left_indices:
			x1: float = interval_list[j]; y1: float = ue_list[j] 

			for k in right_indices:
				x2: float = interval_list[k]; y2: float = ue_list[k] 

				signal_value: float = compute_yline(x2, y2, x1, y1, prior[0])
				isvalid: bool = True

				for l in range(j+1,k):
					if (ue_list[l] <= compute_yline(x2,y2,x1,y1,interval_list[l])):
						isvalid = False
						break

				if isvalid:
					pair_list.append((j,k))
					value_list.append(signal_value)

		# Determine \mu^a and \mu^b
		min_val: float = min(value_list)
		val_index: int = value_list.index(min_val)

		min_xpair: tuple = ((pair_list[val_index])[0], (pair_list[val_index])[1])

		return min_val

itr_range = ast.literal_eval(sys.argv[-1])
itr_list = [i for i in range(itr_range[0],itr_range[1] + 1)]

# Number of considered support-files
data_nr: int = 40

# Initialize counters
honestisopt_counter: int = 0
isconcave_counter: int = 0
isconvex_counter: int = 0
is_strictconcave_counter: int = 0
is_strictconvex_counter: int = 0
isline_counter: int = 0
support_counter: int = 0

honest_opt: float = 0.
nosignal_opt: float = 0.
opt_pointso: float = 0.
opt_pointue: float = 0.
UE_all: float = 0.
SO_all: float = 0.
poa: float = 0.

isline: bool = False
support_nr_list: list = []

print("Considering data sets...")
for itr in itr_list:

	try:
		file = open('./loop_results/stat_data/cleared/supports_{0}.txt'.format(itr))
	except FileNotFoundError:
		print("Skipping File ",itr)
		continue
	
	file = open('./loop_results/stat_data/cleared/supports_{0}.txt'.format(itr))
	content = file.readlines()
	# Number of lines skipped in file
	offset: int = 2 

	tau_value: float = ast.literal_eval(content[11 + offset])
	support_nr: int = ast.literal_eval(content[12 + offset])
	route: tuple = ast.literal_eval(content[13 + offset])
	demand: int = ast.literal_eval(content[14 + offset])
	#UE_list: list = ast.literal_eval(content[15 + offset])
	SO_list: list = ast.literal_eval(content[16 + offset])
	gamma_list: list = ast.literal_eval(content[17 + offset])
	UE_cost_list: list = ast.literal_eval(content[18 + offset])
	alpha_list: list = ast.literal_eval(content[19 + offset])

	initNode = route[0]
	termNode = route[1]

	support_nr_list.append(support_nr)
	support_counter += support_nr

	# Special case: number of distinct supports is one
	if (len(UE_cost_list) == 3):
		isline = True
		isline_counter += 1
		isconcave_counter += 1
		isconvex_counter += 1
		honestisopt_counter += 1
		honestisopt = True

	else:
		# Check if C(\mu_{\theta_1}) is *strictly* concave
		isconcave: bool = check_concave(UE_cost_list, alpha_list)
		if isconcave:
			isconcave_counter += 1
			is_strictconcave_counter += 1

		
		# Check if C(\mu_{\theta_1}) is *strictly* convex
		isconvex: bool = check_convex(UE_cost_list, alpha_list)
		if isconvex:
			isconvex_counter += 1
			is_strictconvex_counter += 1
		
		# Check if full information revelation is optimal
		honestisopt: bool = check_honestopt(UE_cost_list, alpha_list, isconcave)
		if honestisopt:
			honestisopt_counter += 1
	
	# Compute the cost of no-signaling
	nosignal_cost: float = compute_cost_nosignal(q_list, UE_cost_list, alpha_list)
	
	# Compute cost of full information revelation
	honest_cost: float = compute_cost_honest(q_list, UE_cost_list)
	
	# Compute the mean cost of pointwise Social Optimum at prior
	meanSO_cost: float = compute_cost_avgSO(q_list, SO_list)
	
	# Compute cost of optimal signaling scheme
	opt_cost: float = compute_cost_opt(q_list, UE_cost_list, honestisopt, alpha_list)

	honest_opt += honest_cost / opt_cost
	nosignal_opt += nosignal_cost / opt_cost
	opt_pointso += opt_cost / meanSO_cost
	poa += nosignal_cost / meanSO_cost

dem: float = demand
tau: float = tau_value[0][0]

print("Calculating ratios...")
# Compute ratios
honestisopt_ratio: float = honestisopt_counter / data_nr
isconcave_ratio: float = isconcave_counter / data_nr
isconvex_ratio: float = isconvex_counter / data_nr
is_strictconcave_ratio: float = is_strictconcave_counter / data_nr
is_strictconvex_ratio: float = is_strictconvex_counter / data_nr
isline_ratio: float = isline_counter / data_nr

# Compute mean cost ratios
honest_opt_global: float = honest_opt / data_nr
nosignal_opt_global: float = nosignal_opt / data_nr
opt_pointso_global: float = opt_pointso / data_nr
poa_global: float = poa / data_nr

# Compute standard deviation of average support number
mean_support_nr: float = support_counter / data_nr
dev_support_nr: float = 0.

for elem in support_nr_list:
	dev_support_nr += (elem - mean_support_nr)**2

if (data_nr > 1):
	dev_support_nr = m.sqrt((dev_support_nr / (data_nr-1)))
else:
	dev_support_nr = 0.

max_support_nr: int = max(support_nr_list)


if dem == 360600.:
	network: str = "SF" 
elif dem == 65576.:
	network: str = "EM" 
elif dem == 11205.:
	network: str = "BF"    
elif dem == 16660.:
	network: str = "BP" 
elif dem == 10755.:
	network: str = "BT" 
elif dem == 11482.:
	network: str = "BC" 

if printtofile:
	print("Printing to file...")
	# Path/name for offset-files
	result_file = "./loop_results/stat_eval/statistics_{0}_tau{1}.txt".format(network, tau)
   
	f = open(result_file, "w")
	f.write("# Run ID: {0}\n".format(dt_string))
	f.write("\n")
	f.write("# Network: {0}\n".format(network))
	f.write("Demand: {0}\n".format(dem))
	f.write("# NR. of data sets: {0}\n".format(data_nr))
	f.write("Prior distribution: {0}\n".format(q_list))
	f.write("\n")
	f.write("# AVG NR. supports: {0:.2f}\n".format(mean_support_nr))
	f.write("# DEV NR. supports: {0:.2f}\n".format(dev_support_nr))
	f.write("# MAX NR. supports: {0:.2f}\n".format(max_support_nr))
	f.write("\n")
	f.write("# REL NR. is honest: {0:.8f}\n".format(honestisopt_ratio))
	f.write("# REL NR. is concave: {0:.8f}\n".format(isconcave_ratio))
	f.write("# REL NR. is convex: {0:.8f}\n".format(isconvex_ratio))
	f.write("# REL NR. is strictly concave: {0:.8f}\n".format(is_strictconcave_ratio))
	f.write("# REL NR. is strictly convex: {0:.8f}\n".format(is_strictconvex_ratio))
	f.write("# REL NR. is line: {0:.8f}\n".format(isline_ratio))
	f.write("\n")
	f.write("# AVG Honest/Optsignal: {0:.8f}\n".format(honest_opt_global))
	f.write("# AVG Nosignal/Optsignal: {0:.8f}\n".format(nosignal_opt_global))
	f.write("# AVG Optsignal/PointwiseSO: {0:.8f}\n".format(opt_pointso_global))
	f.write("# AVG PoA: {0:.8f}\n".format(poa_global))
	
	f.write("{0:.2f}\t{1:.2f}\t{2:.2f}\t{3:.8f}\t{4:.8f}\t{5:.8f}\t{6:.8f}\t{7:.8f}\t{8:.8f}\t{9:.8f}\t{10:.8f}".format(mean_support_nr,
		dev_support_nr,max_support_nr,is_strictconcave_ratio,is_strictconvex_ratio, isline_ratio,honestisopt_ratio,honest_opt_global,
		nosignal_opt_global,opt_pointso_global,poa_global))
	
	f.close()

print("Finished...")    
print()
print("++++ RESULTS +++++")
print("Network: {0}".format(network))
print("Demand: {0}".format(dem))
print("NR. of data sets: {0}".format(data_nr))
print("Prior distribution: {0}".format(q_list))
print()
print("AVG NR. supports: {0:.2f}".format(mean_support_nr))
print("DEV NR. supports: {0:.2f}".format(dev_support_nr))
print("MAX NR. supports: {0:.2f}\n".format(max_support_nr))
print("")
print("REL NR. is honest: {0:.8f}".format(honestisopt_ratio))
print("REL NR. is concave: {0:.8f}".format(isconcave_ratio))
print("REL NR. is convex: {0:.8f}".format(isconvex_ratio))
print("REL NR. is STRICTLY concave: {0:.8f}".format(is_strictconcave_ratio))
print("REL NR. is STRICTLY convex: {0:.8f}".format(is_strictconvex_ratio))
print("REL NR. is line: {0:.8f}".format(isline_ratio))
print("")
print("AVG Honest/Optsignal: {0:.8f}".format(honest_opt_global))
print("AVG Nosignal/Optsignal: {0:.8f}".format(nosignal_opt_global))
print("AVG Optsignal/PointwiseSO: {0:.8f}".format(opt_pointso_global))
print("AVG PoA: {0:.8f}".format(poa_global))
print("---------")