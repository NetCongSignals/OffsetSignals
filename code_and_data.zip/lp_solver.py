"""
This code is an implementation of the LP  defined by the linear constraints in (4)
together with Eq. (9). The LP is applied as described in the proof of Prop. 3 in
'compute_data.py'.
"""

import numpy as np
from scipy.optimize import linprog
import os
import sys
from cvxopt import matrix, solvers
module_path = os.path.abspath(os.path.join('./Traffic-Assignment-Frank-Wolfe-2021-main'))
if module_path not in sys.path:
    sys.path.append(module_path)

from assignment import FlowTransportNetwork

# Display information on LP-solver or not
lp_verbose = True
 
# LP to compute bounds of subinterval for given support
def computeAlpha(supp_ind: list, supp_inst: list, no_supp_ind: list, no_supp_inst: list, 
	initNode: int, termNode: int, network, max_a1: bool, demand: float):

	node_nr: int = len(network.nodeSet) + 2
	
	# Nodes 316, 317 skipped in BT; Node 43 skipped in BC
	if (network.name == 'BT'):
		node_nr += 2
	elif (network.name == 'BC'):
		node_nr += 1

	link_nr: int = len(network.linkSet)
	alpha_nr: int = 2 # Two scenarios

	total_nr: int = node_nr + link_nr + alpha_nr
	support_nr: int = len(supp_ind)
	no_support_nr: int = len(no_supp_ind)

	support_inits = [int(supp.init_node)-1 for supp in supp_inst]
	support_terms = [int(supp.term_node)-1 for supp in supp_inst]
	no_support_inits = [int(no_supp.init_node)-1 for no_supp in no_supp_inst]
	no_support_terms = [int(no_supp.term_node)-1 for no_supp in no_supp_inst]

	# Order of variables: 
	# [Dual vector components \pi_1, \pi_2,... , edge loads x_1,x_2,... , \mu_1, \mu_2]


	# DEFINING OBJECTIVE FUNCTION

	# Set the coefficients of the linear objective function vector
	# Here: maximize \mu_{\theta_1} if max_a1 = True, else minimize \mu_{\theta_1}
	if max_a1:
		obj_list = [0 for i in range(node_nr + link_nr)]
		obj_list.extend([-1,0])
		obj = np.array(obj_list)
	else:
		obj_list = [0 for i in range(node_nr + link_nr)]
		obj_list.extend([1,0])		
		obj = np.array(obj_list)


	# DEFINING ALL INEQUALITY CONSTRAINTS

	# Initialize the inequality constraints matrix
	# Note: the inequality constraints must be in the form of <=
	lhs_ineq = []

	# Initalize the inequality constraints vector
	rhs_ineq = []

	# Inequalities for condition on on dual vector components of all edges
	# that are not part of the support (-> Eq. (4))
	for e in range(no_support_nr):
		init: int = no_support_inits[e]
		term: int = no_support_terms[e]
		instance = no_supp_inst[e]
		index: int = no_supp_ind[e]

		potential_ineq = [0 for i in range(node_nr)]
		potential_ineq[init] = -1
		potential_ineq[term] = 1

		lat_slope = [0 for i in range(link_nr)]
		lat_slope[index] = -instance.slope
		potential_ineq.extend(lat_slope)

		potential_ineq.extend([-instance.coeff_b1, -instance.coeff_b2])

		lhs_ineq.append(potential_ineq)
		rhs_ineq.append(0)


	lhs_ineq_np = np.array(lhs_ineq)
	rhs_ineq_np = np.array(rhs_ineq)

	
	# Inequalities for bounds of all variables (-> Eq. (4))
	# Solver assumes all variables to be non-negative by default
	bnds_ineq = []
	bnds_ineq.extend([(0, None) for i in range(node_nr)])
	bnds_ineq.extend([(0, demand) for i in range(link_nr)])
	bnds_ineq.extend([(0, 1) for i in range(alpha_nr)])

	bnds_ineq_np = np.array(bnds_ineq)


	# DEFINING ALL EQUALITY CONSTRAINTS

	# Initialize the equality constraints matrix
	lhs_eq = []

	# Initialize the equality constraints vector
	rhs_eq = []

	# Equalities for linear conditions on the components of the dual vector (-> Eq. (4))
	for e in range(support_nr):
		init: int = support_inits[e]
		term: int = support_terms[e]
		instance = supp_inst[e]
		index: int = supp_ind[e]

		potential_eq = [0 for i in range(node_nr)]
		potential_eq[init] = 1
		potential_eq[term] = -1

		lat_slope = [0 for i in range(link_nr)]
		lat_slope[index] = instance.slope
		potential_eq.extend(lat_slope)
		
		potential_eq.extend([instance.coeff_b1, instance.coeff_b2])

		lhs_eq.append(potential_eq)
		rhs_eq.append(0)

		
	# Equality for \pi_s = 0 for source node s (-> Eq. (4))
	ys_zero = [0 for i in range(total_nr)]
	ys_zero[initNode-1] = 1

	lhs_eq.append(ys_zero)
	rhs_eq.append(0)


	# Equalities for flow conservation (-> Eq. (4))
	for node in range(node_nr):
		if ((node == initNode-1) or (node == termNode-1)):
			continue
		else:
			flow_eq = [0 for i in range(total_nr)]
			for j in range(support_nr):
				init: int = support_inits[j]
				term: int = support_terms[j]

				if (node == init):
					index: int = supp_ind[j]
					flow_eq[node_nr + index] = -1
				elif (node == term):
					index: int = supp_ind[j]
					flow_eq[node_nr + index] = 1

			for k in range(no_support_nr):
				init: int = no_support_inits[k]
				term: int = no_support_terms[k]

				if (node == init):
					index: int = no_supp_ind[k]
					flow_eq[node_nr + index] = -1
				elif (node == term):
					index: int = no_supp_ind[k]
					flow_eq[node_nr + index] = 1

			lhs_eq.append(flow_eq)
			rhs_eq.append(0)	

	# Equalities for demand flowing out of source node s (-> Eq. (4))
	input_eq = [0 for i in range(total_nr)]
	for j in range(support_nr):
		start: int = support_inits[j]
		if (start == (initNode-1)):
			index: int = supp_ind[j]
			input_eq[node_nr + index] = 1

	lhs_eq.append(input_eq)
	rhs_eq.append(demand)

	# Equalities for demand flowing in target node t (-> Eq. (4))
	output_eq = [0 for i in range(total_nr)]
	for j in range(support_nr):
		end: int = support_terms[j]
		if (end == (termNode-1)):
			index: int = supp_ind[j]
			output_eq[node_nr + index] = 1

	lhs_eq.append(output_eq)
	rhs_eq.append(demand)

	# Equality for convex combination of of \mu_1 and \mu_2 (-> Eq. (9))
	alpha_eq = [0 for i in range(node_nr + link_nr)]
	alpha_eq.extend([1,1])

	lhs_eq.append(alpha_eq)
	rhs_eq.append(1)

	# Non-support edges must have flow x_e = 0
	for e in range(no_support_nr):
		zeroflow_eq = [0 for i in range(total_nr)]
		index: int = no_supp_ind[e]
		zeroflow_eq[node_nr + index] = 1

		lhs_eq.append(zeroflow_eq)
		rhs_eq.append(0)

	lhs_eq_np = np.array(lhs_eq)
	rhs_eq_np = np.array(rhs_eq)

	np.set_printoptions(threshold=np.inf)	

	# Solve LP using HiGHs solver of SciPy package with dual simplex method 
	res_ds = linprog(c=obj, A_ub=lhs_ineq_np, b_ub=rhs_ineq_np,
				A_eq=lhs_eq_np, b_eq=rhs_eq_np, bounds=bnds_ineq_np,
				method="highs-ds",
				options={'presolve': True, 'disp': False, 'tol': 1e-08, 'autoscale': False,
				'dual_feasibility_tolerance': 1e-07, 'primal_feasibility_tolerance': 1e-07,
				'ipm_optimality_tolerance': 1e-08, 'integrality': 2})

	# Some options not for HiGHS-solvers
	#options={'presolve': True, 'disp': False, 'tol': 1e-08, 'autoscale': False,
	#			'dual_feasibility_tolerance': 1e-07, 'primal_feasibility_tolerance': 1e-07,
	#			'ipm_optimality_tolerance': 1e-08})

	# Explanation on parameters:
	# More infos on: 
	# 1) https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linprog.html
	# 2) https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html

	# tol: 
	# A tolerance which determines when a residual is “close enough” to zero to be considered exactly zero.
	# default: 1e-08

	# autoscale:
	# Set to True to automatically perform equilibration. 
    # Consider using this option if the numerical values in the constraints are separated by several orders 
    # of magnitude

	# Dual feasibility tolerance for ‘highs-ds’. 
	# The minimum of this and primal_feasibility_tolerance is used for the feasibility tolerance of ‘highs-ipm’.
	# default: 1e-07

	# Primal feasibility tolerance for ‘highs-ds’. 
	# The minimum of this and dual_feasibility_tolerance is used for the feasibility tolerance of ‘highs-ipm’.
	# default_ 1e-07

	# Optimality tolerance for ‘highs-ipm’. Minimum allowable value is 1e-12.

	# Check if highs-ds method did solve LP successfully
	if res_ds.get("success"):

		# Print status
		linprog_status_ds = res_ds.get("status")
		linprog_message_ds = res_ds.get("message")
		print("Status of Lin. Prog. (DS):  {0}".format(linprog_status_ds))
		print("Message of Lin. Prog. (DS): {0}".format(linprog_message_ds))

		# An integer representing the exit status of the algorithm.
		# 0 : Optimization terminated successfully.
		# 1 : Iteration or time limit reached.
		# 2 : Problem appears to be infeasible.
		# 3 : Problem appears to be unbounded.
		# 4 : The HiGHS solver ran into a (numerical) problem.

		print()
		return res_ds

	# If highs-ds was not successful, try again with HiGHS interior point method.
	else:

		res_ipm = linprog(c=obj, A_ub=lhs_ineq_np, b_ub=rhs_ineq_np,
				A_eq=lhs_eq_np, b_eq=rhs_eq_np, bounds=bnds_ineq_np,
				method="highs-ipm",
				options={'presolve': True, 'disp': False, 'tol': 1e-08, 'autoscale': False,
				'dual_feasibility_tolerance': 1e-07, 'primal_feasibility_tolerance': 1e-07,
				'ipm_optimality_tolerance': 1e-08, 'integrality': 2})

		linprog_status_ipm = res_ipm.get("status")
		linprog_message_ipm = res_ipm.get("message")
		print("Status of Lin. Prog. (IPM):  {0}".format(linprog_status_ipm))
		print("Message of Lin. Prog. (IPM): {0}".format(linprog_message_ipm))

		return res_ipm