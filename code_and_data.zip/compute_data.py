"""
Main code for generating the data used in the computational study. 
It computes multiple randomly generated instances for the specified parameters.
Outputs: Report on run and data for each instance (-> ./loop_results/stat_eval/) 
Run 'python3 compute_data.py' to start.
"""

import os
import sys
import numpy as np
import random as rd
import pandas as pd
import copy
from datetime import datetime
from lp_solver import *
module_path = os.path.abspath(os.path.join('./Traffic-Assignment-Frank-Wolfe-2021-main'))
if module_path not in sys.path:
    sys.path.append(module_path)

# Files from 'Traffic-Assignment-Frank-Wolfe-2021-main'
from utils import *
from network_import import *
from assignment import *

codeStart = time.time()


# SPECIFYING PARAMETERS 

# Choose network:
# 0: Sioux Falls 'SF', 360600.
# 1: Eastern Massachusetts (Highway extract) 'EM', 65576.
# 2: Berlin Friedrichshain 'BF', 11205
# 3: Berlin Prenzlauer Berg Center 'BPC', 16660
# 4: Berlin Tiergarten 'BT', 10755
# 5: Berlin Mitte Center 'BC', 11482
net: int = 0

# Share of edges with deviating offsets (\tau)
dev_quota: float = .75

# Number of instances to compute
# loop_offset is ID of report file
loops: int = 40
loop_offset: int = 0

# Precision of equilibrium flow assignment
eq_accuracy_exp: int = 4
eq_accuracy: float = 1/(10**eq_accuracy_exp)

# Choose algorithm for computing flow assignment
# Franke-Wolfe (FW) or Conjugate Frank-Wolfe (CFW)
algo: str = "CFW" # "FW"

# Value for \eta in Eq. (11)
if (net <= 1):
    cost_const: float = 0.15
else:
    cost_const: float = 1.

# Manual infinity value for centroid connectors
my_inf: int = 1e5

# Precision with respect to computing support intervals
precision: float = 16

# Demand specification for single commodity (see Table 1)
if (net == 0):
    dem: float = 360600.
elif (net == 1):
    dem: float = 65576.
elif (net == 2):
    dem: float = 11205.   
elif (net == 3):
    dem: float = 16660.
elif (net == 4):
    dem: float = 10755.
elif (net == 5):
    dem: float = 11482.

# Use predefined (s,t)-pair or generate (s,t)-pairs randomly
fixed_st: bool = False
if (fixed_st):
    initNode: str = str(1)
    endNode: str = str(19)
    min_nodeDistance: int = 1
else:
    initNode: str = str(0)
    endNode: str = str(0) 
    st_list: list = []
    min_nodeDistance: int = 1

# Maximum number of iterations for flow computation 
eq_maxIter: int = 3*5000
# Maximum seconds allowed for the assignment of flow
eq_maxTime: int = 6000000

# Storing number of supports for each loop
support_nmbrs = []

# Boolean to catch errors during runtime.
# Possible errors (all due to numerical issues):
# 1) TypeError: LP "not feasible" for solving by LP-solver
# 2) Division by 0
# 3) Support appears more than once with different subintervals
# 4) \alpha value (-> determination of support interval) occurs more than once
# In all events, the run is restarted
error = False
# List of all loop-IDs that are restarted during runtime
error_list = []

lp_counter = []


# DEFINING FUNCTIONS AND METHODS

# Computes support intervals via recursive approach in Prop. 3
# Here: gam, gamma := \alpha in the paper
def computeSupports(gam, ll_bound, rr_bound,prec=precision):

    global error

    # Check for detected errors in the present loop
    if error:
        return 0
    else:

        if (gam in gamma_list):
            error = True
            error_list.append((loop_counter, 'MG'))
            print("-- ERROR: Gamma appears multiple times! --")
            return 1280000
        try:
            supp = computeAssingment(network=network, algorithm=algo, 
                costFunction=linearCostFunction, systemOptimal=False, verbose=True, 
                accuracy=eq_accuracy, maxIter=eq_maxIter, maxTime=eq_maxTime,gamma=gam)

        except ZeroDivisionError:
            error = True
            error_list.append((loop_counter, 'D0'))
            print("-- ERROR: Division by 0! --")
            return 1300000
        
        # Local lists for storage of indices and internal names ("instance") of all 
        # support and non-support edges, resp.
        supp_Index = []
        supp_Instances = []
        no_supp_Index = []
        no_supp_Instances = []
        
        # Get internal name and index related to all edges
        l: int = 0
        for i in network.linkSet:
            # Determine support edges
            if (network.linkSet[i].flow > 0.):
                supp_Index.append(l)
                supp_Instances.append(network.linkSet[i])
            else:
                no_supp_Index.append(l)
                no_supp_Instances.append(network.linkSet[i])
            l += 1

        # If the same support appears multiple times and the respective
        # subintervals are consecutive, fix this, by fusing the subintervals
        # together (since caused by numerical issues) 
        if (supp_Index in supp_Indexlist):
            print("-- WARNING: Support appears multiple times! --")
            entry: int = supp_Indexlist.index(supp_Index)
            resp_alpha_min: float = alpha_list[entry][0]
            resp_alpha_max: float = alpha_list[entry][1]

            # Factor and precision for reaching into next subinterval
            off_fac_ext: float = 0.95
            prec2: int = 10

            # Fusing subinterval [a_1,a_2] with adjacent subinterval [a_2,...]
            if (ll_bound == resp_alpha_max):
                print("--- Trying to extend TO THE RIGHT")
                if (round(rr_bound - gam, prec2) == 0.):
                    alpha_list[entry] = (resp_alpha_min, rr_bound)
                    return 0
                else:
                    alpha_list[entry] = (resp_alpha_min, gam)
                    computeSupports(gam=gam + (rr_bound-gam)*off_fac_ext,
                            ll_bound=gam,rr_bound=rr_bound)

            # Fusing subinterval [a_1,a_2] with adjacent subinterval [...,a_1]
            elif (rr_bound == resp_alpha_min):
                print("--- Trying to extend TO THE LEFT")
                if (round(gam - ll_bound, prec2) == 0.):
                    alpha_list[entry] = (ll_bound, resp_alpha_max)
                    return 0

                else:
                    alpha_list[entry] = (gam, resp_alpha_max)
                    computeSupports(gam=gam + (ll_bound-gam)*off_fac_ext,
                            ll_bound=ll_bound,rr_bound=gam)

            # If subintervals are not consecutive, return error
            else:
                error = True
                error_list.append((loop_counter,'MS'))
                print("-- ERROR: Support appears multiple times! --")
                return 1290000

        else:
            # Specify how far next \alpha advances into next subinterval
            off_fac: float = 0.5 # alternatively: rd.uniform(0.4,0.6) 

            # Store values over all loops
            supp_Indexlist.append(supp_Index)
            no_supp_Indexlist.append(no_supp_Index)
            supp_Instancelist.append(supp_Instances)
            no_supp_Instancelist.append(no_supp_Instances);
            gamma_list.append(gam)

            # Compute lower bound x of support subinterval [x,y]
            # computeAlpha from file 'lp_solver.py' 
            lp_min = computeAlpha(supp_ind=supp_Index, supp_inst=supp_Instances, 
                    no_supp_ind=no_supp_Index, no_supp_inst=no_supp_Instances,
                    initNode=int(initNode), termNode=int(endNode), network=network, 
                    max_a1=False, demand=dem)

            # Compute upper bound y of supprt subinterval [x,y]
            lp_max = computeAlpha(supp_ind=supp_Index, supp_inst=supp_Instances, 
                    no_supp_ind=no_supp_Index, no_supp_inst=no_supp_Instances,
                    initNode=int(initNode), termNode=int(endNode), network=network, 
                    max_a1=True, demand=dem) 

            # Check if LP was solved successfully
            if lp_min.get("success"):
                lp_counter.append(1)
            if lp_max.get("success"):
                lp_counter.append(1)

            # Get computed results for \mu_{\theta_1} in both LPs 
            sol_min = lp_min.get("x")[-2]
            sol_max = lp_max.get("x")[-2]

            # Store boundaries x and y of subinterval [x,y]
            alpha_list.append((sol_min,sol_max))

            # Proceed recursively by looking for not yet considered subintervals
            # > Case 1: Yet considered subintervals cover [0,1] completely -> terminate

            ll_ismatched: bool = (round(sol_min - ll_bound, prec) == 0.)
            rr_ismatched: bool = (round(rr_bound - sol_max, prec) == 0.)

            if (ll_ismatched and rr_ismatched): 
                return 0

            # > Case 2: Yet considered subintervals do not cover [0,1] completely 
            
            else:
                # > Case 2a: For current subinterval [x,y], there are uncovered
                # subintervals in [0,x] and [y,1] 
                # => continue search in [0,x] and [y,1]
                if ((not ll_ismatched) and (not rr_ismatched)):
                    computeSupports(gam=sol_min + (ll_bound-sol_min)*off_fac,
                        ll_bound=ll_bound,rr_bound=sol_min)
                    
                    computeSupports(gam=sol_max + (rr_bound-sol_max)*off_fac,
                        ll_bound=sol_max,rr_bound=rr_bound)

                # > Case 2b: For current subinterval [x,y], there are uncovered
                # subintervals in [0,x]
                # => continue search in [0,x]
                elif (not ll_ismatched):
                    computeSupports(gam=sol_min + (ll_bound-sol_min)*off_fac,
                        ll_bound=ll_bound,rr_bound=sol_min)

                # > Case 2c: For current subinterval [x,y], there are uncovered
                # subintervals in [y,1]
                # => continue search in [y,1]
                elif (not rr_ismatched):
                    computeSupports(gam=sol_max + (rr_bound-sol_max)*off_fac,
                        ll_bound=sol_max,rr_bound=rr_bound)


# Specifies how to write generated data to the support- and report-files
def writeResults(file: str):

    support_inits = []; no_support_inits = []
    support_terms = []; no_support_terms = []
    support_slopes = []; no_support_slopes = []
    support_coeff_b1 = []; no_support_coeff_b1 = []
    support_coeff_b2 = []; no_support_coeff_b2 = []

    supp_counter: int = 0
    for suppo in supp_Indexlist:
        si = []
        st = []
        ss = []
        sb1 = []
        sb2 = []
        for edge in range(len(suppo)):
            instance = supp_Instancelist[supp_counter][edge]
            init = int(instance.init_node) - 1
            term = int(instance.term_node) - 1

            si.append(init); st.append(term)

            ss.append(instance.slope)
            sb1.append(instance.coeff_b1)
            sb2.append(instance.coeff_b2)

        support_inits.append(si)
        support_terms.append(st)
        support_slopes.append(ss)
        support_coeff_b1.append(sb1)
        support_coeff_b2.append(sb2)
        supp_counter += 1

    no_supp_counter: int = 0
    for no_supp in no_supp_Indexlist:
        nsi = []
        nst = []
        nss = []
        nsb1 = []
        nsb2 = []
        for edge in range(len(no_supp)):
            instance = no_supp_Instancelist[no_supp_counter][edge]
            init = int(instance.init_node) - 1
            term = int(instance.term_node) - 1

            nsi.append(init); nst.append(term)

            nss.append(instance.slope)
            nsb1.append(instance.coeff_b1)
            nsb2.append(instance.coeff_b2)

        no_support_inits.append(nsi)
        no_support_terms.append(nst)
        no_support_slopes.append(nss)
        no_support_coeff_b1.append(nsb1)
        no_support_coeff_b2.append(nsb2)
        no_supp_counter += 1

    support_nmbr = len(supp_Indexlist)

    # Write to file
    with open(file, 'a') as f:
        f.write("{0}\n".format(str(supp_Indexlist)))
        f.write("{0}\n".format(str(no_supp_Indexlist)))
        f.write("{0}\n".format(str(support_inits)))
        f.write("{0}\n".format(str(no_support_inits)))
        f.write("{0}\n".format(str(support_terms)))
        f.write("{0}\n".format(str(no_support_terms)))
        f.write("{0}\n".format(str(support_slopes)))
        f.write("{0}\n".format(str(no_support_slopes)))
        f.write("{0}\n".format(str(support_coeff_b1)))
        f.write("{0}\n".format(str(no_support_coeff_b1)))
        f.write("{0}\n".format(str(support_coeff_b2)))
        f.write("{0}\n".format(str(no_support_coeff_b2)))
        f.write("{0}\n".format(support_nmbr))
        f.write("{0}\n".format(str([int(initNode),int(endNode)])))
        f.write("{0}\n".format(dem))
        print("Supports written: {0}".format(support_nmbr))


# Determines indices of opposed edges (i,j) and (j,i)
def matchLinks(network: FlowTransportNetwork):
    same_links = []
    considered_keys = []
    keys = list(network.linkSet.keys()) 
    values = list(network.linkSet.values())

    unmatched_nmbr: int = 0  

    for l in range(len(keys)):
        if keys[l] in considered_keys:
            continue
        else:
            reverse_exists = False
            for m in range(l+1,len(keys)):
                if ((values[l].init_node == values[m].term_node) 
                    and (values[l].term_node == values[m].init_node)):
                    
                    same_links.append((keys[l],keys[m])) 
                    considered_keys.extend([keys[l],keys[m]])
                    reverse_exists = True
                    break

            # If no opposed edge (j,i) exists for edge (i,j),
            # use keys twice in tuple
            if (not reverse_exists):
                unmatched_nmbr += 1
                same_links.append((keys[l],keys[l])) 
                considered_keys.extend([keys[l]])

    # Return list of tuples            
    return same_links


# Identifies centroid connectors
# Each centroid together with the nodes connected to it defines a zone
def findConnectors(network: FlowTransportNetwork, orig, dest):
    to_orig: list = []
    from_orig: list = []
    to_dest: list = []
    from_dest: list = []
    misc_connectors: list = []
   
    # Index of first thru node in underlying data file
    # thru node: node that is not a (artifical) centroid
    first_thru: int = len(network.zoneSet)

    keys = list(network.linkSet.keys()) 
    values = list(network.linkSet.values()) 

    for l in range(len(keys)):
        key: tuple = keys[l]
        value: int = values[l]

        if (value.init_node == orig):   
            from_orig.append(key)
        elif (value.init_node == dest):
            from_dest.append(key)
        elif (value.term_node == orig):   
            to_orig.append(key)
        elif (value.term_node == dest):
            to_dest.append(key)
        elif ((int(value.init_node) < first_thru) or (int(value.term_node) < first_thru)):
            misc_connectors.append(key)

    return to_orig, from_orig, to_dest, from_dest, misc_connectors


# GET META DATA 

# Current date and time
now = datetime.now()
dt_string = now.strftime("%b/%d/%Y %H:%M:%S")
print("RUN STARTED: {0}".format(dt_string))
  
# Sioux Falls
if (net == 0):
    net_file = str(PathUtils.sioux_falls_net_file)
    network_name = 'SF'
# Eastern Massachusetts
elif (net == 1):
    net_file = str(PathUtils.eastern_massachusetts_net_file)
    network_name = 'EM'
# Berlin Friedrichshain
elif (net == 2):
    net_file = str(PathUtils.berlin_friedrichshain_net_file)
    network_name = 'BF'
# Berlin Prenzlauer Berg Center
elif (net == 3):
    net_file = str(PathUtils.berlin_prenzlauerberg_center_net_file)
    network_name = 'BPC'
# Berlin Tiergarten
elif (net == 4):
    net_file = str(PathUtils.berlin_tiergarten_net_file)
    network_name = 'BT'
# Berlin Mitte Center
elif (net == 5):
    net_file = str(PathUtils.berlin_mitte_center_net_file)
    network_name = 'BC'
else:
    net_file = str(not_existing)
    network_name = 'NONE'
    print("No proper network name chosen.")

print("Network: {0}".format(network_name))

# Generate header for report-file of the run 
report_file = "./loop_results/stat_data/report_data_{0}.txt".format(loop_offset)
with open(report_file, 'w') as f:
    f.write("# +++ REPORT FILE +++\n")
    f.write("# Run ID: {0}\n".format(dt_string))
    f.write("#\n")
    f.write("# Network: {0}\n".format(network_name))
    f.write("# Demand: {0}\n".format(dem))
    f.write("# Loop number: {0}\n".format(loops))
    f.write("# Algo: {0}\n".format(algo))
    f.write("# Precision: {0}\n".format(precision))
    f.write("# Eq accuracy: {0}\n".format(eq_accuracy))
    f.write("# Eq max iter: {0}\n".format(eq_maxIter))
    f.write("# Eq max time: {0}\n".format(eq_maxTime))
    f.write("# Deviating quota: {0}\n".format(dev_quota))
    f.write("# Minimum node name distance: {0}\n".format(min_nodeDistance))
    f.write("# My infinity: {0}\n".format(my_inf))
    f.write("# Cost function constant: {0}\n".format(cost_const))


# LOADING NETWORK 

creatingStart = time.time()
demand_file: str = None
verbose: bool = False
force_net_reprocess: bool = False

print()
print("- Loading network...")
network = load_network(net_file=net_file, demand_file=demand_file, verbose=verbose,
 force_net_reprocess=force_net_reprocess)
network.name = network_name
network_size: int = len(network.linkSet)
zone_nmbr: int = len(network.zoneSet)

# |Z| = |E| for SF and EM
if (net > 1):
    true_net_size: int = int(network_size/2 - zone_nmbr)


# Initialize loop control parameters
loop_counter: int = 0 
itr: int = loop_offset
while itr < loop_offset + loops:

    print()
    print("-------------------------------------------------")
    print("Now computing run {0}/{1}...".format(itr+1,loop_offset + loops))


    # Drawing source s and target t
    aresame: bool = True
    aretrip: bool = False
    if (not fixed_st):
        while (aresame and (not aretrip)):
            initNode = str(int(rd.randint(1,zone_nmbr)))
            endNode = str(int(rd.randint(1,zone_nmbr)))

            if (abs(int(initNode) - int(endNode)) >= min_nodeDistance):
                aresame = False

            try: 
                network.tripSet[initNode, endNode].demand = 0.
                aretrip = True
            except KeyError:
                aresame = True
                continue

    network.reset_flow()

    # Set \eta initially back to default when computing a new instance 
    for l in network.linkSet:
        network.linkSet[l].alpha = cost_const

    
    # SPECIFYING BOTH STATES OF NATURE

    network.nodeList = list(network.nodeSet.keys())
    network.zoneList = list(network.zoneSet.keys())    

    # Set demand between s and t to dem; otherwise to 0.
    for r in network.zoneList:
        for s in network.zoneList:
            if ((r == initNode) and (s == endNode)):
                # Use custom demand:
                    network.tripSet[r, s].demand = dem
                
            else:
                try:
                    network.tripSet[r, s].demand = 0.0  
                except KeyError:
                    continue


    # CREATING STATES OF THE WORLD
    # Offsets of edges opposed edges (i,j) and (j,i) deviate in the same manner.

    # max_offset is +25% of maximum fft-value among all edges
    max_fft: float = 0.
    for l in network.linkSet:
        if (network.linkSet[l].fft > max_fft):
            max_fft = network.linkSet[l].fft
    min_offset: int = 0
    max_offset: int = int(1.25 * max_fft)  

    # Generate random offsets
    alternate_offsets = np.random.randint(min_offset, max_offset + 1, 
            int(network_size/2))

    # Draw list of edges that are going to have state-dependent offsets
    # Centroid connectors are excluded
    if (net > 1):
        dev_nr: int = int(true_net_size * dev_quota)

        allowed_indices: list = []
        allowed_indices.extend(range(zone_nmbr,int(network_size/2))) 

        dev_indices = np.random.permutation(allowed_indices)[0:dev_nr]

    else:
        dev_nr: int = int(network_size/2 * dev_quota) # upper rounding used
        dev_indices = np.random.permutation(int(network_size/2))[0:dev_nr]

    # Write to report-file
    with open(report_file, 'a') as f:
        f.write("# Deviating number: {0}\n".format(dev_nr))
        f.write("# Deviating indicies: {0}\n".format(dev_indices))

    # Identify all opposed edges (i,j) and (j,i)
    link_pairs = matchLinks(network)

    # Practically remove centroid connectors for all Berlin-based networks:
    # connectors going out from s have cost 0, connectors entering s have cost my_inf
    # vice versa for connectors of t
    # init := s, term := t
    if (net > 1):
        to_init, from_init, to_term, from_term, rest_connectors = findConnectors(network, 
            initNode, endNode)

    k: int = 0
    for l in link_pairs:
        link1_key = l[0]
        link2_key = l[1]

        if (net > 1):
            if (link1_key in to_init):
                network.linkSet[link1_key].alpha = my_inf
                network.linkSet[link1_key].coeff_b1 = my_inf
                network.linkSet[link1_key].coeff_b2 = my_inf
            
                # Then link2 from init
                network.linkSet[link2_key].alpha = 0.
                network.linkSet[link2_key].coeff_b1 = 0.
                network.linkSet[link2_key].coeff_b2 = 0.

                # Skip rest of iteration
                continue

            elif (link1_key in from_init):
                network.linkSet[link1_key].alpha = 0.
                network.linkSet[link1_key].coeff_b1 = 0.
                network.linkSet[link1_key].coeff_b2 = 0.

                # Then link2 to_init
                network.linkSet[link2_key].alpha = my_inf
                network.linkSet[link2_key].coeff_b1 = my_inf
                network.linkSet[link2_key].coeff_b2 = my_inf
            
                continue

            elif (link1_key in to_term):
                network.linkSet[link1_key].alpha = 0.
                network.linkSet[link1_key].coeff_b1 = 0.
                network.linkSet[link1_key].coeff_b2 = 0.
            
                # Then link2 from dest
                network.linkSet[link2_key].alpha = my_inf
                network.linkSet[link2_key].coeff_b1 = my_inf
                network.linkSet[link2_key].coeff_b2 = my_inf

                continue

            elif (link1_key in from_term):
                network.linkSet[link1_key].alpha = my_inf
                network.linkSet[link1_key].coeff_b1 = my_inf
                network.linkSet[link1_key].coeff_b2 = my_inf

                # Then link2 to dest
                network.linkSet[link2_key].alpha = 0.
                network.linkSet[link2_key].coeff_b1 = 0.
                network.linkSet[link2_key].coeff_b2 = 0.
            
                continue

            elif (link1_key in rest_connectors):
                network.linkSet[link1_key].alpha = my_inf
                network.linkSet[link1_key].coeff_b1 = my_inf
                network.linkSet[link1_key].coeff_b2 = my_inf

                network.linkSet[link2_key].alpha = my_inf
                network.linkSet[link2_key].coeff_b1 = my_inf
                network.linkSet[link2_key].coeff_b2 = my_inf

                continue

        # Specify offsets for each edge in both scenarios according to Eq. (11)
        if (k in dev_indices):
            scenario: int = rd.randint(0,1)

            if (scenario == 0):
                new_offset_0: int = float(alternate_offsets[k])

                while (new_offset_0 == network.linkSet[link1_key].fft):
                    new_offset_0 = np.random.randint(min_offset, max_offset + 1)

                network.linkSet[link1_key].coeff_b1 = new_offset_0
                network.linkSet[link1_key].coeff_b2 = network.linkSet[link1_key].fft
                network.linkSet[link2_key].coeff_b1 = new_offset_0
                network.linkSet[link2_key].coeff_b2 = network.linkSet[link2_key].fft

            else:
                new_offset_1: int = float(alternate_offsets[k])

                while (new_offset_1 == network.linkSet[link1_key].fft):
                    new_offset_1 = np.random.randint(min_offset, max_offset + 1)

                network.linkSet[link1_key].coeff_b1 = network.linkSet[link1_key].fft 
                network.linkSet[link1_key].coeff_b2 = new_offset_1
                network.linkSet[link2_key].coeff_b1 = network.linkSet[link2_key].fft 
                network.linkSet[link2_key].coeff_b2 = new_offset_1

        else:
            network.linkSet[link1_key].coeff_b1 = network.linkSet[link1_key].fft
            network.linkSet[link1_key].coeff_b2 = network.linkSet[link1_key].fft 
            network.linkSet[link2_key].coeff_b1 = network.linkSet[link2_key].fft
            network.linkSet[link2_key].coeff_b2 = network.linkSet[link2_key].fft

        k += 1


    # DETERMINING SUPPORTS

    # Initialize support-files containing simulation data for specific instance
    support_file = "./loop_results/stat_data/supports_{0}.txt".format(itr)
    with open(support_file, 'w') as f:
        f.write("# +++ SUPPORT DATA FILE +++\n")
        f.write("# Run ID: {0}\n".format(dt_string))

    # Stores the indices (since Dictionary is ordered)
    supp_Indexlist = []; no_supp_Indexlist = []
    # Stores the respective internal names
    supp_Instancelist = []; no_supp_Instancelist = []
    # Stores relevant \alpha values for exploring the subintervals
    gamma_list = []
    # Stores values of Wardrop equilibria cost C at each breakpoint
    # UE (User Equilibrium) := Wardrop equilibrium (WE)
    list_UE = []
    # Stores all support subintervals
    alpha_list = []
    # Stores costs of WE and Social Optimum (SO) for
    # \mu_{\theta_1} = 0 and \mu_{\theta_1} = 1
    UE_list = []; SO_list = [] 

    print("- Calculating alpha-values...")

    error = False
    error_post = False

    # Catch error by 'infeasible' LP
    try:
        sol = computeSupports(gam=0.5, ll_bound=0., rr_bound=1., prec=precision)
    except TypeError:
        error = True
        error_list.append((loop_counter, 'TE'))
        print("-- ERROR: TypeError! --")
        print(supp_Indexlist)

    try:
        if (error == False):
            # Write results to support-file
            print("- Writing results...")
            writeResults(file=support_file)

            support_nmbr = len(supp_Indexlist)
            support_nmbrs.append(support_nmbr)

            print("- Computing UE and SO...")

            # Sort lists in ascending order
            gam_list, al_tuple_list = (list(t) for t in zip(*sorted(zip(gamma_list, alpha_list))))

            al_tuple_write = [(0,0)]
            al_tuple_write.extend(al_tuple_list)
            al_tuple_write.append((1,1))

            gam_list_write = [0]
            gam_list_write.extend(gam_list)
            gam_list_write.append(1)

            list_UE_write = []

            # Compute costs of WE at all subinterval boundaries plus at mu_{\theta_1}=0 
            # and \mu_{\theta_1}=1
            for item in al_tuple_write:
                UE = computeAssingment(network=network, algorithm=algo, 
                    costFunction=linearCostFunction, systemOptimal=False, verbose=True, 
                    accuracy=eq_accuracy, maxIter=eq_maxIter, maxTime=eq_maxTime,
                    gamma=item[1])

                list_UE_write.append(UE)

            # Compute costs of SO at mu_{\theta_1}=0 and \mu_{\theta_1}=1 
            SO_0 = computeAssingment(network=network, algorithm=algo, 
                costFunction=linearCostFunction, systemOptimal=True, verbose=True, 
                accuracy=eq_accuracy, maxIter=eq_maxIter, maxTime=eq_maxTime,gamma=0.)

            SO_1 = computeAssingment(network=network, algorithm=algo, 
                costFunction=linearCostFunction, systemOptimal=True, verbose=True, 
                accuracy=eq_accuracy, maxIter=eq_maxIter, maxTime=eq_maxTime,gamma=1.)

            # Write cost of WE to list
            UE_list.extend([])
            SO_list.extend([SO_0, SO_1])

            # Write to support-file
            print("- Writing UE and SO...")
            with open(support_file, 'a') as f:
                f.write("{0}\n".format(str(UE_list)))
                f.write("{0}\n".format(str(SO_list)))
                f.write("{0}\n".format(str(gam_list_write)))
                f.write("{0}\n".format(str(list_UE_write)))
                f.write("{0}\n".format(str(al_tuple_write)))

            print()
            print("RUN {0} COMPLETED!".format(itr+1))
            itr += 1

        else:
            print()
            print("RESTARTING RUN {0}!".format(itr+1))

    except ZeroDivisionError:
            error_post = True
            error_list.append((loop_counter, 'D0'))
            print("-- ERROR: Division by 0 in POST!<-<-<-<-<-<-<-<-<-<-<-<")
            print()
            print("RESTARTING RUN {0}!".format(itr+1))

    # Print to command line
    if ((error == False) and (error_post == False)):
        print()
        print(list_UE_write)
        print(al_tuple_write)
        print(gam_list_write)
        if (not fixed_st):
            st_list.append((initNode,endNode))
    
    loop_counter += 1

# GENERATING REPORTS 

# Print overview to report file
with open(report_file, 'a') as f:
    f.write("# Offset min: {0}\n".format(min_offset))
    f.write("# Offset max: {0}\n".format(max_offset))
    if (fixed_st):
        f.write("# Start node: {0}\n".format(initNode))
        f.write("# Term node: {0}\n".format(endNode))
    else:
        f.write("# Nr. of st-pairs: {0}\n".format(len(st_list)))
        f.write("# List of st-pairs: {0}\n".format(st_list))
    f.write("\n")
    f.write("# Aimed number of runs: {0}\n".format(loops))
    f.write("# Actual number of runs: {0}\n".format(loop_counter))
    f.write("# Total comp. time: {0} secs\n".format(round(time.time() - codeStart, 2)))
    f.write("# Erroreous runs: {0}\n".format(error_list))
    f.write("# LPs solved: {0}\n".format(len(lp_counter)))
    f.write("{0}\n".format(support_nmbrs))

# Print overview to command line
print()
print("++++ REPORT ++++")
print("Aimed number of runs: {0}\n".format(loops))
print("Actual number of runs: {0}\n".format(loop_counter))
print("Erroreous runs: {0}\n".format(error_list))
print("LPs solved: {0}\n".format(len(lp_counter)))
print()
print("Total computation time:", round(time.time() - codeStart, 2), "secs.")
print("Nr. of supports: {0}\n".format(support_nmbrs))
if (not fixed_st):
    print("OD pairs:", st_list)